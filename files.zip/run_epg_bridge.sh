#!/bin/bash
# ========================================================
#   AI EPG BRIDGE v2.0 - LAUNCHER WITH GIT AUTOMATION
# ========================================================

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "======================================================"
echo "  AI EPG BRIDGE v2.0 - Auto-Push to GitHub"
echo "======================================================"
echo

# Check for .env
if [ ! -f ".env" ]; then
    echo "[ERROR] .env file not found!"
    echo "Please copy .env.example to .env and configure your settings."
    exit 1
fi

# Check for Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 not found"
    echo "Please install Python 3.8 or higher."
    exit 1
fi

# Check for Git
if ! command -v git &> /dev/null; then
    echo "[ERROR] Git not found"
    echo "Please install Git."
    exit 1
fi

# Use virtual environment if it exists
if [ -d "venv" ]; then
    echo "[*] Activating virtual environment..."
    source venv/bin/activate
elif [ -d "venv_nas" ]; then
    echo "[*] Activating NAS virtual environment..."
    source venv_nas/bin/activate
fi

# Install dependencies if needed
if [ ! -f "logs/install_check.lock" ]; then
    echo "[1/4] First run - Installing dependencies..."
    pip install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to install dependencies."
        exit 1
    fi
    mkdir -p logs
    echo "installed" > "logs/install_check.lock"
else
    echo "[1/4] Dependencies already installed."
fi

# Pull latest changes from GitHub
echo "[2/4] Syncing with GitHub..."
git pull origin main
if [ $? -ne 0 ]; then
    echo "[WARNING] Git pull failed. Continuing anyway..."
fi
echo

# Run the EPG Bridge
echo "[3/4] Generating EPG data..."
echo
python3 src/main.py
if [ $? -ne 0 ]; then
    echo "[ERROR] EPG generation failed!"
    exit 1
fi
echo

# Push to GitHub
echo "[4/4] Pushing to GitHub..."
git add .
git commit -m "Auto-Update EPG: $(date +'%Y-%m-%d %H:%M:%S')"
if [ $? -ne 0 ]; then
    echo "[INFO] No changes to commit."
else
    git push origin main
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to push to GitHub!"
        echo "Please check your Git credentials and repository access."
        exit 1
    fi
    echo "[SUCCESS] Changes pushed to GitHub!"
fi

echo
echo "======================================================"
echo "  Process Complete - EPG Updated and Published"
echo "======================================================"
